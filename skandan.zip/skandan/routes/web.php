<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('report','App\Http\Controllers\SuperAdminController@report');

Route::get('advertisments','App\Http\Controllers\SignInController@all_promotions');


Route::post('reset_password','App\Http\Controllers\SignInController@reset_password');


Route::get('payment','App\Http\Controllers\StudentCartController@payment');
// Route::get('/signin', function () {
//     return view('signin');
// });
Route::get('index','App\Http\Controllers\SignInController@loginform');
Route::get('signup','App\Http\Controllers\SignInController@signup');

Route::post('register','App\Http\Controllers\SignInController@register');

Route::get('/','App\Http\Controllers\SignInController@index');
Route::get('signin','App\Http\Controllers\SignInController@loginform');
Route::post('login','App\Http\Controllers\SignInController@login');
Route::get('profile','App\Http\Controllers\SignInController@profile');
Route::get('signout','App\Http\Controllers\SignInController@signout');

Route::get('chat','App\Http\Controllers\StudentChatController@chat');
Route::post('send_message','App\Http\Controllers\StudentChatController@send_message');


Route::get('chat_messages','App\Http\Controllers\BusinessOwnerController@chat_messages');
Route::post('bo_send_message','App\Http\Controllers\BusinessOwnerController@send_message');


Route::get('/forgot', function () {
    return view('forgot');
});

Route::get('/contactus', function () {
    return view('contactus');
});

Route::get('/about', function () {
    return view('about');
});




Route::get('/edit_student','App\Http\Controllers\SignInController@edit_student');
Route::post('/update_student','App\Http\Controllers\SignInController@update_student');

Route::get('orders','App\Http\Controllers\StudentOrdersController@orders');



Route::get('cart','App\Http\Controllers\StudentCartController@cart');
Route::get('/remove/{itemID}', 'App\Http\Controllers\StudentCartController@remove');

Route::get('posts','App\Http\Controllers\PostsController@posts');
Route::get('/delete_post/{postID}', 'App\Http\Controllers\PostsController@remove');


Route::get('clubs','App\Http\Controllers\StudentClubsController@clubs');
Route::post('/new_club','App\Http\Controllers\StudentClubsController@new_club');
Route::get('/new_club_form','App\Http\Controllers\StudentClubsController@new_club_form');
Route::get('/join_club/{clubID}', 'App\Http\Controllers\StudentClubsController@join');
Route::get('/leave_club/{clubID}', 'App\Http\Controllers\StudentClubsController@leave');


Route::get('buy_products','App\Http\Controllers\StudentProductsController@buy_products');
Route::get('/student_buy_product/{productID}', 'App\Http\Controllers\StudentProductsController@buy');


Route::get('business_owner','App\Http\Controllers\BusinessOwnerController@dashboard');
Route::post('add_product_bo','App\Http\Controllers\BusinessOwnerController@add_product');
Route::get('/bo_all_products', 'App\Http\Controllers\BusinessOwnerController@all_products');
Route::get('/bo_delete_product/{productID}', 'App\Http\Controllers\BusinessOwnerController@delete');
Route::get('/bo_all_promotions', 'App\Http\Controllers\BusinessOwnerController@all_promotions');
Route::get('/bo_delete_promotion/{promotionID}', 'App\Http\Controllers\BusinessOwnerController@delete_promo');
Route::post('add_promo_bo','App\Http\Controllers\BusinessOwnerController@add_promotion');


Route::get('/sp_manage_students', 'App\Http\Controllers\SuperAdminController@all_students');
Route::get('/sp_delete_student/{studentID}', 'App\Http\Controllers\SuperAdminController@delete_student');

Route::get('/sp_manage_bo', 'App\Http\Controllers\SuperAdminController@all_business_owners');
Route::get('/sp_manage_school_admins', 'App\Http\Controllers\SuperAdminController@all_school_admins');


Route::get('/sch_manage_students', 'App\Http\Controllers\SchoolAdminController@all_students');
Route::get('/sc_delete_student/{studentID}', 'App\Http\Controllers\SchoolAdminController@delete_student');

Route::get('/sc_manage_bo', 'App\Http\Controllers\SchoolAdminController@all_business_owners');




Route::get('/sell_products', function () {
    return view('sell_products');
});






// Route::get('/bo_add_promotion', function () {
//     return view('bo_add_promotion');
// });


