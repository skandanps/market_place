

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";




/* Database: `vxk6765_market_place_vikas` */

CREATE TABLE messages
(
id integer NOT NULL AUTO_INCREMENT,
bo_id varchar(100) NOT NULL,
bo_name varchar(100) not null,
student_id varchar(100) NOT NULL,
student_name varchar(100) not null,
initiated_by varchar(20) not null,
PRIMARY KEY (id),
message varchar(1000) not null default ".",
msg_time DATETIME DEFAULT CURRENT_TIMESTAMP
)

CREATE TABLE `bus_o` (
  `cust_name` varchar(100) NOT NULL,
  `frst_name` varchar(20) NOT NULL,
  `lst_name` varchar(20) DEFAULT NULL,
  `cell_number` varchar(15) DEFAULT NULL,
  `eml_cust_id` varchar(100) DEFAULT NULL,
  `adrs` varchar(100) DEFAULT NULL,
  `bus_name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `bus_o` (`cust_name`, `frst_name`, `lst_name`, `cell_number`, `eml_cust_id`, `adrs`, `bus_name`) VALUES
('bussownr@gmail.com', 'james', 'king', '9999999999', 'bussownr@gmail.com', 'UTA, Arlington', ' north mall');


CREATE TABLE `clb` (
  `cust_id` int(11) NOT NULL,
  `clb_name` varchar(200) NOT NULL,
  `clb_dscrption` varchar(700) DEFAULT NULL,
  `clb_own_name` varchar(50) DEFAULT NULL,
  `clb_strt_date` date DEFAULT NULL,
  `clb_rating` varchar(15) DEFAULT NULL,
  `clb_photo` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `clb` (`cust_id`, `clb_name`, `clb_dscrption`, `clb_own_name`, `clb_strt_date`, `clb_rating`, `clb_photo`) VALUES
(1, 'Student Club', 'Student Club', 'student123@gmail.com', '2022-11-05', '4', 'https://sxk6918.uta.cloud/mp_assets/club1.png'),
(2, 'Music Club', 'Music Club', 'student123@gmail.com', '2022-11-05', '4', 'https://sxk6918.uta.cloud/mp_assets/club2.jpeg');


CREATE TABLE `clb_std` (
  `cust_id` int(11) NOT NULL,
  `stud_name` varchar(50) NOT NULL,
  `stud_strt_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `clb_std` (`cust_id`, `stud_name`, `stud_strt_date`) VALUES
(2, 'student123@gmail.com', '2022-11-06');


CREATE TABLE `cust` (
  `cust_name` varchar(100) NOT NULL,
  `cust_type` varchar(10) NOT NULL,
  `pwd` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `cust` (`cust_name`, `cust_type`, `pwd`) VALUES
('alex@gmail.com', 'stud', 'Phase@888'),
('bussownr@gmail.com', 'bus_o', 'Phase@777'),
('john@gmail.com', 'stud', 'Phase@999'),
('schl@gmail.com', 'sh_adm', 'Phase@777'),
('sp@gmail.com', 'sp_adm', 'Phase@777'),
('student123@gmail.com', 'stud', 'Phase@777');



CREATE TABLE `cust_qry` (
  `cust_id` int(11) NOT NULL,
  `cust_name` varchar(100) NOT NULL,
  `eml_cust_id` varchar(100) DEFAULT NULL,
  `qry_txt` varchar(700) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `cust_qry` (`cust_id`, `cust_name`, `eml_cust_id`, `qry_txt`) VALUES
(1, 'student123@gmail.com', 'student123@gmail.com', 'mock Text mock Text 1'),
(2, 'student123@gmail.com', 'student123@gmail.com', 'mock Text mock Text 2'),
(4, 'student123@gmail.com', 'student123@gmail.com', 'Sample Query Sample Query'),
(5, 'student123@gmail.com', 'student123@gmail.com', 'Query Query Query asdfasd');



CREATE TABLE `messg` (
  `cust_id` int(11) NOT NULL,
  `messg_txt` text,
  `src_cust` varchar(50) DEFAULT NULL,
  `dst_cust` varchar(50) DEFAULT NULL,
  `strt_time` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `posts` (
  `cust_id` int(11) NOT NULL,
  `ps_name` varchar(150) NOT NULL,
  `ps_dscrpt` varchar(750) DEFAULT NULL,
  `ps_strt_date` date DEFAULT NULL,
  `ps_url` varchar(125) DEFAULT NULL,
  `ps_photo` varchar(125) DEFAULT NULL,
  `ps_rating` varchar(15) DEFAULT NULL,
  `own_name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `posts` (`cust_id`, `ps_name`, `ps_dscrpt`, `ps_strt_date`, `ps_url`, `ps_photo`, `ps_rating`, `own_name`) VALUES
(1, 'Mobile fame', 'Mobiles are becoming more and more used rin recent data', '2022-11-08', '', 'https://www.kindpng.com/picc/m/422-4225211_new-mobile-phone-png-transparent-cartoons-smart-phones.png', '4', 'student123@gmail.com'),
(3, 'Web apps', 'Web app trends', '2022-11-08', '', 'https://www.kindpng.com/picc/m/422-4225211_new-mobile-phone-png-transparent-cartoons-smart-phones.png', '4', 'student123@gmail.com'),
(5, 'Social Media influence', 'Influence of social media on kids', '2022-11-08', '', 'https://www.kindpng.com/picc/m/422-4225211_new-mobile-phone-png-transparent-cartoons-smart-phones.png', '4', 'student123@gmail.com'),
(6, 'Web apps', 'Web app trends', '2022-11-08', '', 'https://www.kindpng.com/picc/m/422-4225211_new-mobile-phone-png-transparent-cartoons-smart-phones.png', '4', 'student123@gmail.com');



CREATE TABLE `prdct` (
  `cust_id` int(11) NOT NULL,
  `prdct_name` varchar(150) NOT NULL,
  `prdct_dscrptions` varchar(700) DEFAULT NULL,
  `prdct_count` int(11) DEFAULT NULL,
  `prdct_cost` decimal(10,0) DEFAULT NULL,
  `prdct_strt_date` date DEFAULT NULL,
  `prdct_photo` varchar(150) DEFAULT NULL,
  `own_name` varchar(50) DEFAULT NULL,
  `prdct_discount` decimal(10,0) DEFAULT NULL,
  `rting` varchar(15) DEFAULT NULL,
  `catgry` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `prdct` (`cust_id`, `prdct_name`, `prdct_dscrptions`, `prdct_count`, `prdct_cost`, `prdct_strt_date`, `prdct_photo`, `own_name`, `prdct_discount`, `rting`, `catgry`) VALUES
(1, 'S Bag', 'Super Bag', 4, '20', '2022-11-05', 'https://p3-ofp.static.pub/ShareResource/560x450/SSNP/GX40Q17227/GX40Q17227-560x450-01.bbd132d263290134.png', 'bussownr@gmail.com', '25', '4', 'style'),
(2, 'Nike Bag', 'Nike Bag', 3, '50', '2022-11-05', 'https://m.media-amazon.com/images/I/81awYcAdi7L._AC_SY879_.jpg', 'bussownr@gmail.com', '0', '4', 'style'),
(3, 'Kickers', 'Kickers bag', 2, '22', '2022-11-05', 'https://m.media-amazon.com/images/I/7153AoC56GS._AC_UY1000_.jpg', 'bussownr@gmail.com', '0', '4', 'trend'),
(4, 'R Bag', 'R Bag', 4, '30', '2022-11-05', 'https://www.first-spear.com/img/310/300/resize/catalog/product/f/s/fs_e_r_waist_bag_2.jpg', 'bussownr@gmail.com', '25', '4', 'trend'),
(5, 'Apple Watch', 'Apple Watch', 4, '45', '2022-11-05', 'https://i5.walmartimages.com/asr/606c10f7-24cc-4752-bd8e-4e473ee0852a.7b50883b5327290e35c24e784c323f22.png', 'bussownr@gmail.com', '25', '4', 'tech'),
(6, 'NASA Space Watch', 'NASA Space Watch', 4, '45', '2022-11-05', 'https://cdn.shopify.com/s/files/1/1081/2826/products/nasa-anicorn-richarddanne-spacewatch-3a2b-01.jpg?v=1636296606', 'bussownr@gmail.com', '25', '4', 'tech');


CREATE TABLE `promotion` (
  `cust_id` int(11) NOT NULL,
  `prom_name` varchar(150) NOT NULL,
  `own_name` varchar(50) DEFAULT NULL,
  `prmotion_image` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `promotion` (`cust_id`, `prom_name`, `own_name`, `prmotion_image`) VALUES
(1, '10% Off on techs', 'bussownr@gmail.com', 'https://sxk6918.uta.cloud/mp_assets/watch2.webp'),
(2, '30% Off on techs', 'bussownr@gmail.com', 'https://sxk6918.uta.cloud/mp_assets/watch1.jpg');



CREATE TABLE `sh_adm` (
  `cust_name` varchar(100) NOT NULL,
  `frst_name` varchar(20) NOT NULL,
  `lst_name` varchar(20) DEFAULT NULL,
  `cell_number` varchar(15) DEFAULT NULL,
  `eml_cust_id` varchar(100) DEFAULT NULL,
  `adrs` varchar(100) DEFAULT NULL,
  `sh_name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `sh_adm` (`cust_name`, `frst_name`, `lst_name`, `cell_number`, `eml_cust_id`, `adrs`, `sh_name`) VALUES
('schl@gmail.com', 'smash', 'chowmein', '9999999999', 'schl@gmail.com', 'UTA, houston', 'cambridge Public School');


CREATE TABLE `sp_adm` (
  `cust_name` varchar(100) NOT NULL,
  `frst_name` varchar(20) NOT NULL,
  `lst_name` varchar(20) DEFAULT NULL,
  `cell_number` varchar(15) DEFAULT NULL,
  `eml_cust_id` varchar(100) DEFAULT NULL,
  `adrs` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `sp_adm` (`cust_name`, `frst_name`, `lst_name`, `cell_number`, `eml_cust_id`, `adrs`) VALUES
('sp@gmail.com', 'john', 'roy', '9999999999', 'sp@gmail.com', 'UTA, Arlington');


CREATE TABLE `stud` (
  `cust_name` varchar(100) NOT NULL,
  `frst_name` varchar(20) NOT NULL,
  `lst_name` varchar(20) DEFAULT NULL,
  `cell_number` varchar(15) DEFAULT NULL,
  `eml_cust_id` varchar(100) DEFAULT NULL,
  `adrs` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `stud` (`cust_name`, `frst_name`, `lst_name`, `cell_number`, `eml_cust_id`, `adrs`) VALUES
('alex@gmail.com', 'alex', 'john', '9966655445', 'alex@gmail.com', 'arlington'),
('john@gmail.com', 'John', 'Mav', '2255664488', 'john@gmail.com', 'Arlington'),
('student123@gmail.com', 'stylus', 'ken', '9999999999', 'student123@gmail.com', 'UTA, Arlington');



CREATE TABLE `stud_cart` (
  `stud_cust_name` varchar(50) NOT NULL,
  `prdct_cust_id` int(11) NOT NULL,
  `prdct_count` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `stud_cart` (`stud_cust_name`, `prdct_cust_id`, `prdct_count`) VALUES
('alex@gmail.com', 1, 1),
('student123@gmail.com', 3, 7),
('student123@gmail.com', 4, 1);



CREATE TABLE `stud_ordrs` (
  `stud_cust_name` varchar(100) NOT NULL,
  `prdct_cust_id` int(11) NOT NULL,
  `ord_date` date DEFAULT NULL,
  `cst` int(11) DEFAULT NULL,
  `crnt_status` varchar(20) DEFAULT NULL,
  `rtrn_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



INSERT INTO `stud_ordrs` (`stud_cust_name`, `prdct_cust_id`, `ord_date`, `cst`, `crnt_status`, `rtrn_date`) VALUES
('student123@gmail.com', 1, '2022-11-02', 20, 'done', NULL),
('student123@gmail.com', 2, '2022-11-04', 10, 'processing', NULL),
('student123@gmail.com', 3, '2022-11-02', 10, 'processing', '2022-11-06');



ALTER TABLE `bus_o`
  ADD PRIMARY KEY (`cust_name`);


ALTER TABLE `clb`
  ADD PRIMARY KEY (`cust_id`),
  ADD KEY `clb_own_name` (`clb_own_name`);


ALTER TABLE `clb_std`
  ADD PRIMARY KEY (`cust_id`,`stud_name`),
  ADD KEY `stud_name` (`stud_name`);


ALTER TABLE `cust`
  ADD PRIMARY KEY (`cust_name`);


ALTER TABLE `cust_qry`
  ADD PRIMARY KEY (`cust_id`),
  ADD KEY `cust_name` (`cust_name`);

ALTER TABLE `messg`
  ADD PRIMARY KEY (`cust_id`),
  ADD KEY `src_cust` (`src_cust`),
  ADD KEY `dst_cust` (`dst_cust`);

ALTER TABLE `posts`
  ADD PRIMARY KEY (`cust_id`),
  ADD KEY `own_name` (`own_name`);

ALTER TABLE `prdct`
  ADD PRIMARY KEY (`cust_id`),
  ADD KEY `own_name` (`own_name`);

ALTER TABLE `promotion`
  ADD PRIMARY KEY (`cust_id`),
  ADD KEY `own_name` (`own_name`);

ALTER TABLE `sh_adm`
  ADD PRIMARY KEY (`cust_name`);

ALTER TABLE `sp_adm`
  ADD PRIMARY KEY (`cust_name`);

ALTER TABLE `stud`
  ADD PRIMARY KEY (`cust_name`);

ALTER TABLE `stud_cart`
  ADD PRIMARY KEY (`stud_cust_name`,`prdct_cust_id`),
  ADD KEY `prdct_cust_id` (`prdct_cust_id`);

ALTER TABLE `stud_ordrs`
  ADD PRIMARY KEY (`stud_cust_name`,`prdct_cust_id`),
  ADD KEY `prdct_cust_id` (`prdct_cust_id`);


ALTER TABLE `clb`
  MODIFY `cust_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

ALTER TABLE `cust_qry`
  MODIFY `cust_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

ALTER TABLE `messg`
  MODIFY `cust_id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `posts`
  MODIFY `cust_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

ALTER TABLE `prdct`
  MODIFY `cust_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

ALTER TABLE `promotion`
  MODIFY `cust_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;


ALTER TABLE `bus_o`
  ADD CONSTRAINT `bus_o_ibfk_1` FOREIGN KEY (`cust_name`) REFERENCES `cust` (`cust_name`);

ALTER TABLE `clb`
  ADD CONSTRAINT `clb_ibfk_1` FOREIGN KEY (`clb_own_name`) REFERENCES `cust` (`cust_name`);

ALTER TABLE `clb_std`
  ADD CONSTRAINT `clb_std_ibfk_1` FOREIGN KEY (`cust_id`) REFERENCES `clb` (`cust_id`),
  ADD CONSTRAINT `clb_std_ibfk_2` FOREIGN KEY (`stud_name`) REFERENCES `stud` (`cust_name`);


ALTER TABLE `cust_qry`
  ADD CONSTRAINT `cust_qry_ibfk_1` FOREIGN KEY (`cust_name`) REFERENCES `stud` (`cust_name`);

ALTER TABLE `messg`
  ADD CONSTRAINT `messg_ibfk_1` FOREIGN KEY (`src_cust`) REFERENCES `cust` (`cust_name`),
  ADD CONSTRAINT `messg_ibfk_2` FOREIGN KEY (`dst_cust`) REFERENCES `cust` (`cust_name`);

ALTER TABLE `posts`
  ADD CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`own_name`) REFERENCES `stud` (`cust_name`);

ALTER TABLE `prdct`
  ADD CONSTRAINT `prdct_ibfk_1` FOREIGN KEY (`own_name`) REFERENCES `bus_o` (`cust_name`);

ALTER TABLE `promotion`
  ADD CONSTRAINT `promotion_ibfk_1` FOREIGN KEY (`own_name`) REFERENCES `bus_o` (`cust_name`);

ALTER TABLE `sh_adm`
  ADD CONSTRAINT `sh_adm_ibfk_1` FOREIGN KEY (`cust_name`) REFERENCES `cust` (`cust_name`);

ALTER TABLE `sp_adm`
  ADD CONSTRAINT `sp_adm_ibfk_1` FOREIGN KEY (`cust_name`) REFERENCES `cust` (`cust_name`);

ALTER TABLE `stud`
  ADD CONSTRAINT `stud_ibfk_1` FOREIGN KEY (`cust_name`) REFERENCES `cust` (`cust_name`);

ALTER TABLE `stud_cart`
  ADD CONSTRAINT `stud_cart_ibfk_1` FOREIGN KEY (`stud_cust_name`) REFERENCES `stud` (`cust_name`),
  ADD CONSTRAINT `stud_cart_ibfk_2` FOREIGN KEY (`prdct_cust_id`) REFERENCES `prdct` (`cust_id`);

ALTER TABLE `stud_ordrs`
  ADD CONSTRAINT `stud_ordrs_ibfk_1` FOREIGN KEY (`stud_cust_name`) REFERENCES `stud` (`cust_name`),
  ADD CONSTRAINT `stud_ordrs_ibfk_2` FOREIGN KEY (`prdct_cust_id`) REFERENCES `prdct` (`cust_id`);
COMMIT;



