<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Session;

class PostsController extends Controller {

   public function remove(Request $request)
   {
                  if(Session::get('user_object')!==null )
      {
       $postID = $request->route('postID');
       if(isset($postID))
       {

         $items = DB::select("delete from posts where cust_id = '".$postID."'");
            $user_name = Session::get('user_object')->cust_name;
            $posts = DB::select("SELECT * FROM posts where own_name = '".$user_name."'");
            
           return view('posts')->with('posts', $posts);




         return view('cart')->with('items', $items);
       }
      }
      else
      {
               return view('signin');

      }




   }

   public function posts() {

            if(Session::get('user_object')!==null)
      {
            $user_name = Session::get('user_object')->cust_name;
            $posts = DB::select("SELECT * FROM posts where own_name = '".$user_name."'");
            // echo json_encode($posts);
           return view('posts')->with('posts', $posts);
      }
      else
      {
               return view('signin');

      }

   }
	

}