<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Session;

class SuperAdminController extends Controller {

  public function report()
  {
      

        $club_count = DB::select("select count(*) as cnt from clb;");
        $club_count = $club_count[0]->cnt;

        $student_count = DB::select("select count(*) as cnt from stud;");
        $student_count = $student_count[0]->cnt;




          return view('report')->with(['club_count'=> $club_count,'student_count'=> $student_count]);
    

  }



  public function all_students()
  {
        if(Session::get('user_object')!==null && Session::get('user_type')=="sp_adm")
      {

      $owner_name = Session::get('user_object')[0];
      $user_name = $owner_name->cust_name;

         $items = DB::select("SELECT * FROM stud");
        // echo json_encode($items);

          return view('sp_all_students')->with('students', $items);
    }

  }

  public function all_business_owners()
  {
        if(Session::get('user_object')!==null && Session::get('user_type')=="sp_adm")
      {

      $owner_name = Session::get('user_object')[0];
      $user_name = $owner_name->cust_name;

         $items = DB::select("SELECT * FROM bus_o");
        // echo json_encode($items);

          return view('sp_all_bo')->with('business_owners', $items);
    }

  }


    public function all_school_admins()
  {
        if(Session::get('user_object')!==null && Session::get('user_type')=="sp_adm")
      {

      $owner_name = Session::get('user_object')[0];
      $user_name = $owner_name->cust_name;

         $items = DB::select("SELECT * FROM sh_adm");
        // echo json_encode($items);

          return view('sp_all_school_admin')->with('admins', $items);
    }

  }


  






   public function delete_student(Request $request)
   {
        if(Session::get('user_object')!==null && Session::get('user_type')=="sp_adm")
      {
       $itemID = $request->route('studentID');
       if(isset($itemID))
       {
        $stud_id = $itemID;


         DB::select("delete from clb_std where stud_name = '".$stud_id."'");
         DB::select("delete from cust_qry where cust_name = '".$stud_id."'");
         DB::select("delete from stud_ordrs where stud_cust_name = '".$stud_id."'");
         DB::select("delete from stud_ordrs where stud_cust_name = '".$stud_id."'");
         DB::select("delete from stud_cart where stud_cust_name = '".$stud_id."'");
         DB::select("delete from posts where own_name = '".$stud_id."'");
        DB::select("delete from stud where cust_name = '".$stud_id."'");
         DB::select("delete from cust where cust_name = '".$stud_id."'");

         $items = DB::select("SELECT * FROM stud");
        // echo json_encode($items);

          return view('sp_all_students')->with('students', $items);

       }
             else
      {
               return view('signin');

      }
      }
      else
      {
               return view('signin');

      }




   }





 	

}