<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Session;
use Mail;

class SignInController extends Controller {


    public function all_promotions()
  {
      $items = DB::select("SELECT * FROM promotion");
        // echo json_encode($items);

          return view('advertisments')->with('promotions', $items);
    }

  



   public function index() {

      return view('index');
   }


   public function reset_password(Request $request)
{

            $email = $request->input("emailAddress");
            $user = DB::select("select * from cust where cust_name = '".$email."'");
            if(count($user)==0)
            {
               echo "no user found";
            }
            else
            {
               // echo json_encode($user);

$msg = "Your password is ".$user[0]->pwd;

// use wordwrap() if lines are longer than 70 characters
$msg = wordwrap($msg,70);

// send email
mail($email,"Reset Password",$msg);

      echo "Password sent to email";


            }

}





   public function update_student(Request $request)
   {
         if(Session::get('user_object')!==null && Session::get('user_type')=="stud")
      {
        $user_name = Session::get('user_object')->cust_name;

      $first_name = $request->input("first_name");
      $last_name = $request->input("last_name");
      $cell_number = $request->input("cell_number");
      $address = $request->input("address");
      DB::select("Update stud set frst_name = '".$first_name."',lst_name = '".$last_name."',cell_number= '".$cell_number."',adrs= '".$address."' where cust_name = '".$user_name."'");

                  Session::put('user_type', null);
            Session::put('user_object', null);
            return view('signin');


      
   }
}

   public function edit_student()
   {

      if(Session::get('user_object')!==null && Session::get('user_type')=="stud")
      {

         return view('edit_student')->with('user',Session::get('user_object'));

        // $user_name = Session::get('user_object')->cust_name;
     }



   }




   public function signup()
   {
            return view('signup');

   }

   public function register(Request $request)
   {
        $first_name = $request->input("firstName");
      $last_name = $request->input("lastName");
      $cell_number = $request->input("phoneNumber");
      $address = $request->input("address");
      $email = $request->input("emailAddress");
      $password = $request->input("password");
      DB::select("INSERT INTO cust VALUES ('".$email."', 'stud', '".$password."')");
      DB::select("INSERT INTO stud VALUES('".$email."', '".$first_name."', '".$last_name."', '".$cell_number."', '".$email."', '".$address."')");
      

 // $data = array('name'=>"Virat Gandhi");
   
 //      Mail::send(['text'=>'mail'], $data, function($message) {
 //         $message->to('abc@gmail.com', 'Tutorials Point')->subject
 //            ('Laravel Basic Testing Mail');
 //         $message->from('xyz@gmail.com','Virat Gandhi');
 //      });
 //      echo "Basic Email Sent. Check your inbox.";


$msg = "Please verify your account: click the link below <a href='https://www.citypng.com/public/uploads/preview/-11596149075nhbwnzspuy.png'>Verify</a>";

// use wordwrap() if lines are longer than 70 characters
$msg = wordwrap($msg,70);

// send email
mail($email,"Verify account",$msg);

      echo "Registration successful\n";
      echo "<a href='signin'> Login </a>";


       

   }



   public function signout() {
            Session::put('user_type', null);
            Session::put('user_object', null);
      return view('signin');
   }


   public function loginform() {
      if(Session::get('user_object')!==null && Session::get('user_type')=="stud")
      {
         return view('profile')->with('user', Session::get('user_object'));
      }
      if(Session::get('user_object')!==null && Session::get('user_type')=="bus_o")
      {
         return view('business_owner')->with('user', Session::get('user_object'));
      }
      if(Session::get('user_object')!==null && Session::get('user_type')=="sp_adm")
      {
         return view('super_admin_dashboard')->with('user', Session::get('user_object'));
      }
      if(Session::get('user_object')!==null && Session::get('user_type')=="sh_adm")
      {
         return view('school_admin_dashboard')->with('user', Session::get('user_object'));
      }
      
      return view('signin');
   }


   public function profile() {
      if(Session::get('user_object')!==null && Session::get('user_type')=="stud")
      {
         return view('profile')->with('user', Session::get('user_object'));
      }
      return view('signin');
   }
   
   public function login(Request $request) {
      $email = $request->input('email');
      $password = $request->input('password');
      $user = (DB::table('cust')->where('cust_name',$email)->get());

      if(count($user)==0)
      {
      echo "Incorrect email/password.<br/>";
      echo '<a href = "/signin">Click Here</a> to go back.';

      }
      else
      {
         $obj = $user[0];
         if($obj->pwd==$password)
         {
            $customer_type = $obj->cust_type;
            if($customer_type == "stud")
            {

            $user = (DB::table($customer_type)->where('cust_name',$email)->get());
            $user= $user[0];
            Session::put('user_type', $customer_type);
            Session::put('user_object', $user);
            // Session::get('variableName');
            return view('profile')->with('user', $user);
            }
            else if($customer_type == "bus_o")
            {
               Session::put('user_type', $customer_type);
            Session::put('user_object', $user);
            // Session::get('variableName');
            return view('business_owner')->with('user', $user);

            }
            else if($customer_type =="sp_adm")
            {

            Session::put('user_type', $customer_type);
            Session::put('user_object', $user);
            // Session::get('variableName');
            return view('super_admin_dashboard')->with('user', $user);

            }
            else if($customer_type =="sh_adm")
            {

            Session::put('user_type', $customer_type);
            Session::put('user_object', $user);
            // Session::get('variableName');
            return view('school_admin_dashboard')->with('user', $user);

            }
      

         }
         else
         {
            echo "Incorrect email/password.<br/>";
            echo '<a href = "/signin">Click Here</a> to go back.';
         }

      }





   }
}