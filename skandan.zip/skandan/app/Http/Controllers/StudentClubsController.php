<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Session;

class StudentClubsController extends Controller {

      public function new_club_form()
      {
        return view('new_club_form');
      }


    public function new_club(Request $request)
    {
                        if(Session::get('user_object')!==null && Session::get('user_type')=="stud")
      {
        $user_name = Session::get('user_object')->cust_name;
            $name = $request->input('name');
            $description = $request->input('description');

            DB::select("INSERT INTO `clb` (`clb_name`, `clb_dscrption`, `clb_own_name`, `clb_strt_date`, `clb_rating`, `clb_photo`) VALUES
('".$name."', '".$description."', '".$user_name."', '2022-11-05', '4', 'https://sxk6918.uta.cloud/mp_assets/club1.png')");


                        $joined_clubs = DB::select("select * from clb where cust_id in (select cust_id from clb_std where stud_name = '".$user_name."')");
            $not_joined_clubs = DB::select("select * from clb where cust_id not in (select cust_id from clb_std where stud_name = '".$user_name."')");
            // echo json_encode($not_joined_clubs);
            return view('clubs')->with(['joined_clubs'=> $joined_clubs, 'not_joined_clubs'=>$not_joined_clubs]);

          }

    }

   public function leave(Request $request)
   {
                  if(Session::get('user_object')!==null && Session::get('user_type')=="stud")
      {
        $user_name = Session::get('user_object')->cust_name;
       $clubID = $request->route('clubID');
       if(isset($clubID))
       {

         $items = DB::select("DELETE from clb_std where cust_id = '".$clubID."' and stud_name = '".$user_name."'");
                     $joined_clubs = DB::select("select * from clb where cust_id in (select cust_id from clb_std where stud_name = '".$user_name."')");
            $not_joined_clubs = DB::select("select * from clb where cust_id not in (select cust_id from clb_std where stud_name = '".$user_name."')");
            // echo json_encode($not_joined_clubs);
            return view('clubs')->with(['joined_clubs'=> $joined_clubs, 'not_joined_clubs'=>$not_joined_clubs]);


       }
      }
      else
      {
               return view('signin');

      }




   }


   public function join(Request $request)
   {
                  if(Session::get('user_object')!==null && Session::get('user_type')=="stud")
      {
       $clubID = $request->route('clubID');
       if(isset($clubID))
       {
          $user_name = Session::get('user_object')->cust_name;

            DB::select("INSERT INTO clb_std values ('".$clubID."', '".$user_name."', '2022-11-06')");
            $joined_clubs = DB::select("select * from clb where cust_id in (select cust_id from clb_std where stud_name = '".$user_name."')");
            $not_joined_clubs = DB::select("select * from clb where cust_id not in (select cust_id from clb_std where stud_name = '".$user_name."')");
            // echo json_encode($not_joined_clubs);
            return view('clubs')->with(['joined_clubs'=> $joined_clubs, 'not_joined_clubs'=>$not_joined_clubs]);

       }
      }
      else
      {
               return view('signin');

      }




   }





   public function clubs() {
            if(Session::get('user_object')!==null && Session::get('user_type')=="stud")
      {
            $user_name = Session::get('user_object')->cust_name;
            $joined_clubs = DB::select("select * from clb where cust_id in (select cust_id from clb_std where stud_name = '".$user_name."')");
            $not_joined_clubs = DB::select("select * from clb where cust_id not in (select cust_id from clb_std where stud_name = '".$user_name."')");
            // echo json_encode($not_joined_clubs);
            return view('clubs')->with(['joined_clubs'=> $joined_clubs, 'not_joined_clubs'=>$not_joined_clubs]);

      }
      else
      {
               return view('signin');

      }

   }
	

}