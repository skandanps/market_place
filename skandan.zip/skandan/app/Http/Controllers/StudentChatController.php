<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Session;

class StudentChatController extends Controller {

   public function chat()
   {


         $business_owners = DB::select("SELECT * FROM bus_o");
        // echo json_encode($business_owners);
                    $user_name = Session::get('user_object')->cust_name;
        // echo json_encode(Session::get('user_object'));
        $messages = DB::select("SELECT * FROM messages where student_id = '".$user_name."' order by id Desc"); 
         return view('chat')->with(['business_owners'=> $business_owners,'messages'=> $messages,'student'=> Session::get('user_object')]);

   }

   public function send_message(Request $request )
   {
        $message = $request->input("message");
        $bo_id = $request->input("bo_id");
        $bo_name = $request->input("bo_name");
        $student_id = $request->input("student_id");
        $student_name = $request->input("student_name");
        $initiated_by = $request->input("initiated_by");
        DB::select("insert into messages (message,bo_id,bo_name,student_id,student_name,initiated_by) values ('".$message."','".$bo_id."','".$bo_name."','".$student_id."','".$student_name."', 'student')");

         $business_owners = DB::select("SELECT * FROM bus_o");
                             $user_name = Session::get('user_object')->cust_name;
        // echo json_encode(Session::get('user_object'));
        $messages = DB::select("SELECT * FROM messages where student_id = '".$user_name."' order by id Desc"); 
         return view('chat')->with(['business_owners'=> $business_owners,'messages'=> $messages,'student'=> Session::get('user_object')]);




   }

   public function orders() {

            if(Session::get('user_object')!==null && Session::get('user_type')=="stud")
      {
            $user_name = Session::get('user_object')->cust_name;
            $active_orders = DB::select("select * from stud_ordrs a, prdct b where a.prdct_cust_id = b.cust_id and a.stud_cust_name = '".Session::get('user_object')->cust_name."' and a.crnt_status = 'processing'");
            // echo json_encode($active_orders);
            $past_orders = DB::select("select * from stud_ordrs a, prdct b where a.prdct_cust_id = b.cust_id and a.stud_cust_name = '".Session::get('user_object')->cust_name."' and a.crnt_status = 'done'");
            return view('orders')->with(['active_orders'=> $active_orders, 'past_orders'=>$past_orders]);
      }
      else
      {
               return view('signin');

      }
}
   
	

}