<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Session;

class StudentCartController extends Controller {

	public function payment()
{
	return view('payment');
}




   public function remove(Request $request)
   {
                  if(Session::get('user_object')!==null && Session::get('user_type')=="stud")
      {
       $itemID = $request->route('itemID');
       if(isset($itemID))
       {

         $items = DB::select("delete from stud_cart where stud_cust_name = '".Session::get('user_object')->cust_name."' and prdct_cust_id = '".$itemID."'");
            $user_name = Session::get('user_object')->cust_name;
            $items = DB::select("select prdct.*, stud_cart.prdct_count as p_cnt from prdct, stud_cart where prdct.cust_id = stud_cart.prdct_cust_id and prdct.cust_id in (select prdct_cust_id from stud_cart where stud_cust_name = '".$user_name."')");
            // echo json_encode($items);




         return view('cart')->with('items', $items);
       }
      }
      else
      {
               return view('signin');

      }




   }

   public function cart() {

            if(Session::get('user_object')!==null && Session::get('user_type')=="stud")
      {
            $user_name = Session::get('user_object')->cust_name;
            $items = DB::select("select prdct.*, stud_cart.prdct_count as p_cnt from prdct, stud_cart where prdct.cust_id = stud_cart.prdct_cust_id and prdct.cust_id in (select prdct_cust_id from stud_cart where stud_cust_name = '".$user_name."')");
            // echo json_encode($items);




         return view('cart')->with('items', $items);
      }
      else
      {
               return view('signin');

      }

   }
	

}