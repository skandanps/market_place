<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Session;

class BusinessOwnerController extends Controller {


   public function chat_messages()
   {


         $students = DB::select("SELECT * FROM stud");
        $user_name = Session::get('user_object')[0]->cust_name;
        $messages = DB::select("SELECT * FROM messages where bo_id = '".$user_name."' order by id Desc"); 
         return view('bo_chat')->with(['students'=> $students,'messages'=> $messages,'business_owner'=> Session::get('user_object')[0]]);

   }

   public function send_message(Request $request )
   {

        $message = $request->input("message");
        $bo_id = $request->input("bo_id");
        $bo_name = $request->input("bo_name");
        $student_id = $request->input("student_id");
        $student_name = $request->input("student_name");
        $initiated_by = $request->input("initiated_by");
        DB::select("insert into messages (message,bo_id,bo_name,student_id,student_name,initiated_by) values ('".$message."','".$bo_id."','".$bo_name."','".$student_id."','".$student_name."', 'Business Owner')");
         $students = DB::select("SELECT * FROM stud");
        $user_name = Session::get('user_object')[0]->cust_name;
        $messages = DB::select("SELECT * FROM messages where bo_id = '".$user_name."' order by id Desc"); 


         return view('bo_chat')->with(['students'=> $students,'messages'=> $messages,'business_owner'=> Session::get('user_object')[0]]);




   }




  public function all_products()
  {
        if(Session::get('user_object')!==null && Session::get('user_type')=="bus_o")
      {

      $owner_name = Session::get('user_object')[0];
      $user_name = $owner_name->cust_name;

         $items = DB::select("SELECT * FROM prdct where own_name = '".$user_name."'");
        // echo json_encode($items);

          return view('bo_add_product')->with('products', $items);
    }

  }


    public function all_promotions()
  {
        if(Session::get('user_object')!==null && Session::get('user_type')=="bus_o")
      {

      $owner_name = Session::get('user_object')[0];
      $user_name = $owner_name->cust_name;

      $items = DB::select("SELECT * FROM promotion where own_name = '".$user_name."'");
        // echo json_encode($items);

          return view('bo_add_promotion')->with('promotions', $items);
    }

  }

  public function dashboard()
  {
      return view('signin');

  }


   public function delete(Request $request)
   {
        if(Session::get('user_object')!==null && Session::get('user_type')=="bus_o")
      {
       $itemID = $request->route('productID');
       if(isset($itemID))
       {

         DB::select("delete from stud_cart where prdct_cust_id = '".$itemID."'");
         DB::select("delete from stud_ordrs where prdct_cust_id = '".$itemID."'");
         DB::select("delete from prdct where cust_id = '".$itemID."'");


            
      $owner_name = Session::get('user_object')[0];
      $user_name = $owner_name->cust_name;

         $items = DB::select("SELECT * FROM prdct where own_name = '".$user_name."'");
        // echo json_encode($items);

          return view('bo_add_product')->with('products', $items);
       }
             else
      {
               return view('signin');

      }
      }
      else
      {
               return view('signin');

      }




   }


      public function delete_promo(Request $request)
   {
        if(Session::get('user_object')!==null && Session::get('user_type')=="bus_o")
      {
       $itemID = $request->route('promotionID');
       if(isset($itemID))
       {

         DB::select("delete from promotion where cust_id = '".$itemID."'");
               $owner_name = Session::get('user_object')[0];
      $user_name = $owner_name->cust_name;

      $items = DB::select("SELECT * FROM promotion where own_name = '".$user_name."'");
        // echo json_encode($items);

          return view('bo_add_promotion')->with('promotions', $items);


            

       }
             else
      {
               return view('signin');

      }
      }
      else
      {
               return view('signin');

      }




   }



   public function add_product(Request $request)
   {
      if(Session::get('user_object')!==null && Session::get('user_type')=="bus_o")
      {
      $name= $request->input('name');
      $link = $request->input('url');
      $price = $request->input('price');


      $prod_name = $name;
      $prod_desc = $name;
      $count = 10;
      $cost = $price;
      $start_date = '2022-11-06';
      $prod_pic = $link;
      // echo json_encode(Session::get('user_object'));

      $owner_name = Session::get('user_object')[0];
      $owner_name = $owner_name->cust_name;

      DB::select("INSERT INTO prdct(prdct_name, prdct_dscrptions, prdct_count, prdct_cost, prdct_strt_date, prdct_photo, own_name, prdct_discount, rting, catgry) 
            VALUES ('".$prod_name."', '".$prod_name."', '".$count."', '".$cost."', '".$start_date."', '".$prod_pic."', '".$owner_name."', 0, '4.5', '')");

      return view('business_owner');

 
      }
      else
      {
               return view('signin');

      }
   }



   public function add_promotion(Request $request)
   {
      if(Session::get('user_object')!==null && Session::get('user_type')=="bus_o")
      {
      $name= $request->input('name');
      $link = $request->input('url');


    $prod_name = $name;
    $prod_desc = $name;
    $count = 10;
    // $cost = $data -> price;
    $start_date = '2022-11-06';
    $prod_pic = $link;



      $owner_name = Session::get('user_object')[0];
      $owner_name = $owner_name->cust_name;

      DB::select("INSERT INTO promotion(prom_name, own_name, prmotion_image) 
            VALUES ('".$prod_name."','".$owner_name."', '".$prod_pic."')");



      return view('business_owner');

 
      }
      else
      {
               return view('signin');

      }
   }




 	

}