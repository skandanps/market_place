-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: vxk6765_market_place_vikas
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bus_o`
--

DROP TABLE IF EXISTS `bus_o`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bus_o` (
  `cust_name` varchar(100) NOT NULL,
  `frst_name` varchar(20) NOT NULL,
  `lst_name` varchar(20) DEFAULT NULL,
  `cell_number` varchar(15) DEFAULT NULL,
  `eml_cust_id` varchar(100) DEFAULT NULL,
  `adrs` varchar(100) DEFAULT NULL,
  `bus_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`cust_name`),
  CONSTRAINT `bus_o_ibfk_1` FOREIGN KEY (`cust_name`) REFERENCES `cust` (`cust_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bus_o`
--

LOCK TABLES `bus_o` WRITE;
/*!40000 ALTER TABLE `bus_o` DISABLE KEYS */;
INSERT INTO `bus_o` VALUES ('bussownr@gmail.com','james','king','9999999999','bussownr@gmail.com','UTA, Arlington',' north mall');
/*!40000 ALTER TABLE `bus_o` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clb`
--

DROP TABLE IF EXISTS `clb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clb` (
  `cust_id` int NOT NULL AUTO_INCREMENT,
  `clb_name` varchar(200) NOT NULL,
  `clb_dscrption` varchar(700) DEFAULT NULL,
  `clb_own_name` varchar(50) DEFAULT NULL,
  `clb_strt_date` date DEFAULT NULL,
  `clb_rating` varchar(15) DEFAULT NULL,
  `clb_photo` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`cust_id`),
  KEY `clb_own_name` (`clb_own_name`),
  CONSTRAINT `clb_ibfk_1` FOREIGN KEY (`clb_own_name`) REFERENCES `cust` (`cust_name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clb`
--

LOCK TABLES `clb` WRITE;
/*!40000 ALTER TABLE `clb` DISABLE KEYS */;
INSERT INTO `clb` VALUES (1,'Student Club','Student Club','student123@gmail.com','2022-11-05','4','https://sxk6918.uta.cloud/mp_assets/club1.png'),(2,'Music Club','Music Club','student123@gmail.com','2022-11-05','4','https://sxk6918.uta.cloud/mp_assets/club2.jpeg');
/*!40000 ALTER TABLE `clb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clb_std`
--

DROP TABLE IF EXISTS `clb_std`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clb_std` (
  `cust_id` int NOT NULL,
  `stud_name` varchar(50) NOT NULL,
  `stud_strt_date` date DEFAULT NULL,
  PRIMARY KEY (`cust_id`,`stud_name`),
  KEY `stud_name` (`stud_name`),
  CONSTRAINT `clb_std_ibfk_1` FOREIGN KEY (`cust_id`) REFERENCES `clb` (`cust_id`),
  CONSTRAINT `clb_std_ibfk_2` FOREIGN KEY (`stud_name`) REFERENCES `stud` (`cust_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clb_std`
--

LOCK TABLES `clb_std` WRITE;
/*!40000 ALTER TABLE `clb_std` DISABLE KEYS */;
INSERT INTO `clb_std` VALUES (2,'student123@gmail.com','2022-11-06');
/*!40000 ALTER TABLE `clb_std` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cust`
--

DROP TABLE IF EXISTS `cust`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cust` (
  `cust_name` varchar(100) NOT NULL,
  `cust_type` varchar(10) NOT NULL,
  `pwd` varchar(20) NOT NULL,
  PRIMARY KEY (`cust_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cust`
--

LOCK TABLES `cust` WRITE;
/*!40000 ALTER TABLE `cust` DISABLE KEYS */;
INSERT INTO `cust` VALUES ('alex@gmail.com','stud','Phase@888'),('bussownr@gmail.com','bus_o','Phase@777'),('john@gmail.com','stud','Phase@999'),('schl@gmail.com','sh_adm','Phase@777'),('sp@gmail.com','sp_adm','Phase@777'),('student123@gmail.com','stud','Phase@777');
/*!40000 ALTER TABLE `cust` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cust_qry`
--

DROP TABLE IF EXISTS `cust_qry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cust_qry` (
  `cust_id` int NOT NULL AUTO_INCREMENT,
  `cust_name` varchar(100) NOT NULL,
  `eml_cust_id` varchar(100) DEFAULT NULL,
  `qry_txt` varchar(700) DEFAULT NULL,
  PRIMARY KEY (`cust_id`),
  KEY `cust_name` (`cust_name`),
  CONSTRAINT `cust_qry_ibfk_1` FOREIGN KEY (`cust_name`) REFERENCES `stud` (`cust_name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cust_qry`
--

LOCK TABLES `cust_qry` WRITE;
/*!40000 ALTER TABLE `cust_qry` DISABLE KEYS */;
INSERT INTO `cust_qry` VALUES (1,'student123@gmail.com','student123@gmail.com','mock Text mock Text 1'),(2,'student123@gmail.com','student123@gmail.com','mock Text mock Text 2'),(4,'student123@gmail.com','student123@gmail.com','Sample Query Sample Query'),(5,'student123@gmail.com','student123@gmail.com','Query Query Query asdfasd');
/*!40000 ALTER TABLE `cust_qry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `bo_id` varchar(100) NOT NULL,
  `bo_name` varchar(100) NOT NULL,
  `student_id` varchar(100) NOT NULL,
  `student_name` varchar(100) NOT NULL,
  `initiated_by` varchar(20) NOT NULL,
  `message` varchar(1000) NOT NULL DEFAULT '.',
  `msg_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messg`
--

DROP TABLE IF EXISTS `messg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `messg` (
  `cust_id` int NOT NULL AUTO_INCREMENT,
  `messg_txt` text,
  `src_cust` varchar(50) DEFAULT NULL,
  `dst_cust` varchar(50) DEFAULT NULL,
  `strt_time` date DEFAULT NULL,
  PRIMARY KEY (`cust_id`),
  KEY `src_cust` (`src_cust`),
  KEY `dst_cust` (`dst_cust`),
  CONSTRAINT `messg_ibfk_1` FOREIGN KEY (`src_cust`) REFERENCES `cust` (`cust_name`),
  CONSTRAINT `messg_ibfk_2` FOREIGN KEY (`dst_cust`) REFERENCES `cust` (`cust_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messg`
--

LOCK TABLES `messg` WRITE;
/*!40000 ALTER TABLE `messg` DISABLE KEYS */;
/*!40000 ALTER TABLE `messg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `posts` (
  `cust_id` int NOT NULL AUTO_INCREMENT,
  `ps_name` varchar(150) NOT NULL,
  `ps_dscrpt` varchar(750) DEFAULT NULL,
  `ps_strt_date` date DEFAULT NULL,
  `ps_url` varchar(125) DEFAULT NULL,
  `ps_photo` varchar(125) DEFAULT NULL,
  `ps_rating` varchar(15) DEFAULT NULL,
  `own_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`cust_id`),
  KEY `own_name` (`own_name`),
  CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`own_name`) REFERENCES `stud` (`cust_name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` VALUES (1,'Mobile fame','Mobiles are becoming more and more used rin recent data','2022-11-08','','https://www.kindpng.com/picc/m/422-4225211_new-mobile-phone-png-transparent-cartoons-smart-phones.png','4','student123@gmail.com'),(3,'Web apps','Web app trends','2022-11-08','','https://www.kindpng.com/picc/m/422-4225211_new-mobile-phone-png-transparent-cartoons-smart-phones.png','4','student123@gmail.com'),(5,'Social Media influence','Influence of social media on kids','2022-11-08','','https://www.kindpng.com/picc/m/422-4225211_new-mobile-phone-png-transparent-cartoons-smart-phones.png','4','student123@gmail.com'),(6,'Web apps','Web app trends','2022-11-08','','https://www.kindpng.com/picc/m/422-4225211_new-mobile-phone-png-transparent-cartoons-smart-phones.png','4','student123@gmail.com');
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prdct`
--

DROP TABLE IF EXISTS `prdct`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prdct` (
  `cust_id` int NOT NULL AUTO_INCREMENT,
  `prdct_name` varchar(150) NOT NULL,
  `prdct_dscrptions` varchar(700) DEFAULT NULL,
  `prdct_count` int DEFAULT NULL,
  `prdct_cost` decimal(10,0) DEFAULT NULL,
  `prdct_strt_date` date DEFAULT NULL,
  `prdct_photo` varchar(150) DEFAULT NULL,
  `own_name` varchar(50) DEFAULT NULL,
  `prdct_discount` decimal(10,0) DEFAULT NULL,
  `rting` varchar(15) DEFAULT NULL,
  `catgry` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`cust_id`),
  KEY `own_name` (`own_name`),
  CONSTRAINT `prdct_ibfk_1` FOREIGN KEY (`own_name`) REFERENCES `bus_o` (`cust_name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prdct`
--

LOCK TABLES `prdct` WRITE;
/*!40000 ALTER TABLE `prdct` DISABLE KEYS */;
INSERT INTO `prdct` VALUES (1,'S Bag','Super Bag',4,20,'2022-11-05','https://p3-ofp.static.pub/ShareResource/560x450/SSNP/GX40Q17227/GX40Q17227-560x450-01.bbd132d263290134.png','bussownr@gmail.com',25,'4','style'),(2,'Nike Bag','Nike Bag',3,50,'2022-11-05','https://m.media-amazon.com/images/I/81awYcAdi7L._AC_SY879_.jpg','bussownr@gmail.com',0,'4','style'),(3,'Kickers','Kickers bag',2,22,'2022-11-05','https://m.media-amazon.com/images/I/7153AoC56GS._AC_UY1000_.jpg','bussownr@gmail.com',0,'4','trend'),(4,'R Bag','R Bag',4,30,'2022-11-05','https://www.first-spear.com/img/310/300/resize/catalog/product/f/s/fs_e_r_waist_bag_2.jpg','bussownr@gmail.com',25,'4','trend'),(5,'Apple Watch','Apple Watch',4,45,'2022-11-05','https://i5.walmartimages.com/asr/606c10f7-24cc-4752-bd8e-4e473ee0852a.7b50883b5327290e35c24e784c323f22.png','bussownr@gmail.com',25,'4','tech'),(6,'NASA Space Watch','NASA Space Watch',4,45,'2022-11-05','https://cdn.shopify.com/s/files/1/1081/2826/products/nasa-anicorn-richarddanne-spacewatch-3a2b-01.jpg?v=1636296606','bussownr@gmail.com',25,'4','tech');
/*!40000 ALTER TABLE `prdct` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `promotion`
--

DROP TABLE IF EXISTS `promotion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `promotion` (
  `cust_id` int NOT NULL AUTO_INCREMENT,
  `prom_name` varchar(150) NOT NULL,
  `own_name` varchar(50) DEFAULT NULL,
  `prmotion_image` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`cust_id`),
  KEY `own_name` (`own_name`),
  CONSTRAINT `promotion_ibfk_1` FOREIGN KEY (`own_name`) REFERENCES `bus_o` (`cust_name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotion`
--

LOCK TABLES `promotion` WRITE;
/*!40000 ALTER TABLE `promotion` DISABLE KEYS */;
INSERT INTO `promotion` VALUES (1,'10% Off on techs','bussownr@gmail.com','https://sxk6918.uta.cloud/mp_assets/watch2.webp'),(2,'30% Off on techs','bussownr@gmail.com','https://sxk6918.uta.cloud/mp_assets/watch1.jpg');
/*!40000 ALTER TABLE `promotion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sh_adm`
--

DROP TABLE IF EXISTS `sh_adm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sh_adm` (
  `cust_name` varchar(100) NOT NULL,
  `frst_name` varchar(20) NOT NULL,
  `lst_name` varchar(20) DEFAULT NULL,
  `cell_number` varchar(15) DEFAULT NULL,
  `eml_cust_id` varchar(100) DEFAULT NULL,
  `adrs` varchar(100) DEFAULT NULL,
  `sh_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`cust_name`),
  CONSTRAINT `sh_adm_ibfk_1` FOREIGN KEY (`cust_name`) REFERENCES `cust` (`cust_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sh_adm`
--

LOCK TABLES `sh_adm` WRITE;
/*!40000 ALTER TABLE `sh_adm` DISABLE KEYS */;
INSERT INTO `sh_adm` VALUES ('schl@gmail.com','smash','chowmein','9999999999','schl@gmail.com','UTA, houston','cambridge Public School');
/*!40000 ALTER TABLE `sh_adm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sp_adm`
--

DROP TABLE IF EXISTS `sp_adm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sp_adm` (
  `cust_name` varchar(100) NOT NULL,
  `frst_name` varchar(20) NOT NULL,
  `lst_name` varchar(20) DEFAULT NULL,
  `cell_number` varchar(15) DEFAULT NULL,
  `eml_cust_id` varchar(100) DEFAULT NULL,
  `adrs` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`cust_name`),
  CONSTRAINT `sp_adm_ibfk_1` FOREIGN KEY (`cust_name`) REFERENCES `cust` (`cust_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sp_adm`
--

LOCK TABLES `sp_adm` WRITE;
/*!40000 ALTER TABLE `sp_adm` DISABLE KEYS */;
INSERT INTO `sp_adm` VALUES ('sp@gmail.com','john','roy','9999999999','sp@gmail.com','UTA, Arlington');
/*!40000 ALTER TABLE `sp_adm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stud`
--

DROP TABLE IF EXISTS `stud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stud` (
  `cust_name` varchar(100) NOT NULL,
  `frst_name` varchar(20) NOT NULL,
  `lst_name` varchar(20) DEFAULT NULL,
  `cell_number` varchar(15) DEFAULT NULL,
  `eml_cust_id` varchar(100) DEFAULT NULL,
  `adrs` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`cust_name`),
  CONSTRAINT `stud_ibfk_1` FOREIGN KEY (`cust_name`) REFERENCES `cust` (`cust_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stud`
--

LOCK TABLES `stud` WRITE;
/*!40000 ALTER TABLE `stud` DISABLE KEYS */;
INSERT INTO `stud` VALUES ('alex@gmail.com','alex','john','9966655445','alex@gmail.com','arlington'),('john@gmail.com','John','Mav','2255664488','john@gmail.com','Arlington'),('student123@gmail.com','stylus','ken','9999999999','student123@gmail.com','UTA, Arlington');
/*!40000 ALTER TABLE `stud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stud_cart`
--

DROP TABLE IF EXISTS `stud_cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stud_cart` (
  `stud_cust_name` varchar(50) NOT NULL,
  `prdct_cust_id` int NOT NULL,
  `prdct_count` int DEFAULT NULL,
  PRIMARY KEY (`stud_cust_name`,`prdct_cust_id`),
  KEY `prdct_cust_id` (`prdct_cust_id`),
  CONSTRAINT `stud_cart_ibfk_1` FOREIGN KEY (`stud_cust_name`) REFERENCES `stud` (`cust_name`),
  CONSTRAINT `stud_cart_ibfk_2` FOREIGN KEY (`prdct_cust_id`) REFERENCES `prdct` (`cust_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stud_cart`
--

LOCK TABLES `stud_cart` WRITE;
/*!40000 ALTER TABLE `stud_cart` DISABLE KEYS */;
INSERT INTO `stud_cart` VALUES ('alex@gmail.com',1,1),('student123@gmail.com',3,7),('student123@gmail.com',4,1);
/*!40000 ALTER TABLE `stud_cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stud_ordrs`
--

DROP TABLE IF EXISTS `stud_ordrs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stud_ordrs` (
  `stud_cust_name` varchar(100) NOT NULL,
  `prdct_cust_id` int NOT NULL,
  `ord_date` date DEFAULT NULL,
  `cst` int DEFAULT NULL,
  `crnt_status` varchar(20) DEFAULT NULL,
  `rtrn_date` date DEFAULT NULL,
  PRIMARY KEY (`stud_cust_name`,`prdct_cust_id`),
  KEY `prdct_cust_id` (`prdct_cust_id`),
  CONSTRAINT `stud_ordrs_ibfk_1` FOREIGN KEY (`stud_cust_name`) REFERENCES `stud` (`cust_name`),
  CONSTRAINT `stud_ordrs_ibfk_2` FOREIGN KEY (`prdct_cust_id`) REFERENCES `prdct` (`cust_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stud_ordrs`
--

LOCK TABLES `stud_ordrs` WRITE;
/*!40000 ALTER TABLE `stud_ordrs` DISABLE KEYS */;
INSERT INTO `stud_ordrs` VALUES ('student123@gmail.com',1,'2022-11-02',20,'done',NULL),('student123@gmail.com',2,'2022-11-04',10,'processing',NULL),('student123@gmail.com',3,'2022-11-02',10,'processing','2022-11-06');
/*!40000 ALTER TABLE `stud_ordrs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-17 13:10:54
