</body>
  <footer
          class="footer"

          >

      <div class="container text-center text-md-start mt-5">
        <!-- Grid row -->
        <div class="row mt-3">

          <!-- Grid column -->
          <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
            <!-- Links -->
                        <p>
              <a href="/" class="text-dark">Home</a>
            </p>
            <p>
              <a href="/about" class="text-dark">About</a>
            </p>
            <p>
              <a href="/services" class="text-dark">Services</a>
            </p>
            <p>
              <a href="/contactus" class="text-dark">Contact us</a>
            </p>
          </div>
          <!-- Grid column -->

          <!-- Grid column -->
          <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">

            <p>
              <a href="#!" class="text-dark">Blog</a>
            </p>
            <p>
              <a href="#!" class="text-dark">Search</a>
            </p>
            <p>
              <a href="#!" class="text-dark">T&amp;c</a>
            </p>
            <p>
              <a href="#!" class="text-dark">Privacy</a>
            </p>
          </div>
          <!-- Grid column -->


        </div>
        <!-- Grid row -->
      </div>
    
  </footer>
<style type="text/css">
/* Sticky footer styles
-------------------------------------------------- */
html {
  position: relative;
  min-height: 100%;
}
body {
  margin-bottom: 60px; /* Margin bottom by footer height */
}
.footer {
  position: absolute;
  bottom: 0;
  width: 100%;
  height: 2px; /* Set the fixed height of the footer here */
  line-height: 10px; /* Vertically center the text there */
  background-color: #ccc;
}


/* Custom page CSS
-------------------------------------------------- */
/* Not required for template or sticky footer method. */




</style>