<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <title>Profile</title>
  </head>
  <body>

@include('profile-header')
@include('clubs-css')

<div class="container">

<button type="button" type="button" class="btn btn-primary btn-lg float-right" onclick="location.href='/new_club_form';">
    Create new club
</button>
<br>

<h1>

  Join Clubs<hr>
</h1><br>

<div class="row">
    @foreach($not_joined_clubs as $club)
    <div class="col-lg-4">
        <div class="card card-margin">
            <div class="card-header no-border">
                
            </div>
            <div class="card-body pt-0">
                <div class="widget-49">
                    <div class="widget-49-title-wrapper">
                        <div class="widget-49-meeting-info">
                            <h5 class="card-title">{{$club->clb_name}}</h5>
                            <span class="widget-49-meeting-time">Since: {{$club->clb_strt_date}}</span>
                        </div>
                    </div>
                    <ol class="widget-49-meeting-points">
                        <li class="widget-49-meeting-item"><span>{{$club->clb_dscrption}}</span></li>

                    </ol>
                    <div class="widget-49-meeting-action">
                        <a href="/join_club/{{$club->cust_id}}" class="btn btn-sm btn-flash-border-primary">Join</a>
                    </div>
                                        <div class="widget-49-meeting-action">
                        <a href="#" class="btn btn-sm btn-flash-border-primary" onclick="alert('Delete request sent to admin');" >Delete Club</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endforeach
</div>
<br/>
<h1>
  Leave Clubs<hr>
</h1><br>

<div class="row">
    @foreach($joined_clubs as $club)
    <div class="col-lg-4">
        <div class="card card-margin">
            <div class="card-header no-border">
                
            </div>
            <div class="card-body pt-0">
                <div class="widget-49">
                    <div class="widget-49-title-wrapper">
                        <div class="widget-49-meeting-info">
                            <h5 class="card-title">{{$club->clb_name}}</h5>
                            <span class="widget-49-meeting-time">Since: {{$club->clb_strt_date}}</span>
                        </div>
                    </div>
                    <ol class="widget-49-meeting-points">
                        <li class="widget-49-meeting-item"><span>{{$club->clb_dscrption}}</span></li>

                    </ol>
                    <div class="widget-49-meeting-action">
                        <a href="/leave_club/{{$club->cust_id}}" class="btn btn-sm btn-flash-border-primary">Leave</a>
                    </div>
                       <div class="widget-49-meeting-action">
                        <a href="#" class="btn btn-sm btn-flash-border-primary" onclick="alert('Delete request sent to admin');" >Delete Club</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endforeach
</div>




</div>



    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
  @include('footer')
</html>