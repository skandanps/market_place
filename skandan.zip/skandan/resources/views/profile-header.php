<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">

<header>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <div class="container">
        <a class="navbar-brand" href="/profile" style='font-family: "Pacifico", cursive;'>Mercado Escolar</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapse" aria-controls="navbarsExample07" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>


<div class="navbar-collapse collapse w-100 order-3 dual-collapse2" id="collapse">
        <ul class="navbar-nav ml-auto">
             <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Products
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="/buy_products">Buy products</a>
          <a class="dropdown-item" href="/sell_products">Sell products</a>

        </div>
      </li>

            <li class="nav-item">
                <a class="nav-link" href="http://sxp4126.uta.cloud/">Blog</a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="/advertisments">Advertisments</a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="/chat">Chat</a>
            </li>


            <li class="nav-item">
                <a class="nav-link" href="/clubs">Clubs</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="/posts">Posts</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="/orders">Orders</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="/cart">Cart</a>
            </li>
            <li class="nav-item bg-dark" >
                <a class="nav-link" href="/signout">Sign out</a>
            </li>
        </ul>
    </div>

      </div>
    </nav>

      <br>
      <br>
</header>