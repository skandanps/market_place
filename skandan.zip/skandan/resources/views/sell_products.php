<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
 
    <title>Profile</title>
 
    <style type="text/css">

      h1, h2, h3, h4, h5, h6 {
    font-family: "Playfair Display", Georgia, "Times New Roman", serif;
}
    </style>
  </head>
  <body>
<?php include 'profile-header.php';?>

  
<section id="gallery">


  <div class="container">
      <h1 >Sell Products</h1>
  <hr>
    <div class="row">
<div class="col-lg-4 mb-4">
    <div class="card">
      <img src="https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5/19300d1e-0bb6-40ea-b613-9199e4dcd8ac/heritage-backpack-25l-WMP7mb.png" alt="" class="card-img-top">
      <div class="card-body">
        <h5 class="card-title">Nike Bag</h5>
        <p class="card-text">Grab your gear and get going in style with the Nike Heritage Swoosh Backpack, which features 2 zippered pockets to help keep your gear organized. Big and bold, the printed Swoosh graphics have a soft, smooth feel. This product is made with at least 65% recycled polyester.</p>
       <span  class="btn btn-outline-success btn-sm" style="background:#28a745;color: white;" 
       >$20 </span>
       <a onclick="alert('Product placed on marketplace');" class="btn btn-outline-success btn-sm" >Sell Product</a>
      </div>
     </div>
    </div>

    
<div class="col-lg-4 mb-4">
    <div class="card">
      <img src="https://michaelkors.scene7.com/is/image/MichaelKors/MC27350-0001_1?wid=558&hei=748&op_sharpen=1&resMode=sharp2&qlt=90" alt="" class="card-img-top">
      <div class="card-body">
        <h5 class="card-title">Winter coat</h5>
        <p class="card-text">https://michaelkors.scene7.com/is/image/MichaelKors/MC27350-0001_1?wid=558&hei=748&op_sharpen=1&resMode=sharp2&qlt=90</p>
       <span  class="btn btn-outline-success btn-sm" style="background:#28a745;color: white;" 
       >$20 </span>
       <a onclick="alert('Product placed on marketplace');" class="btn btn-outline-success btn-sm" >Sell Product</a>
      </div>
     </div>
    </div>


    <div class="col-lg-4 mb-4">
    <div class="card">
      <img src="https://i8.amplience.net/s/scvl/111751_228494_SET/1?fmt=auto&$webPdpProduct$" alt="" class="card-img-top">
      <div class="card-body">
        <h5 class="card-title">Puma shoe</h5>
        <p class="card-text">I wear these when I have to go out and about, perfect for long distance travel, very good fitting in the sole of my foot and great arch support. They also fit well around my front toes, I sprained my big toe a while back but with this shoe I hardly even notice my old injury. Thanks Puma</p>
       <span  class="btn btn-outline-success btn-sm" style="background:#28a745;color: white;" 
       >$20 </span>
       <a onclick="alert('Product placed on marketplace');" class="btn btn-outline-success btn-sm" >Sell Product</a>
      </div>
     </div>
    </div>



  </div>
</div>
</section>





    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
  @include('footer')
</html>