<style type="text/css">
  /* Show it is fixed to the top */
body {
  padding-top: 7.5rem;
}

</style>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
<header>
 <div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom box-shadow fixed-top"  >
      <h5 class="my-0 mr-md-auto font-weight-normal" style="font-family: 'Pacifico', cursive;"><a href="/">Mercado Escolar</a></h5>
      <nav class="my-2 my-md-0 mr-md-3">
        <a class="p-2 text-dark" href="index">Home</a>
        <a class="p-2 text-dark" href="about">About</a>
        <a class="p-2 text-dark" href="#">Services</a>
        <a class="p-2 text-dark" href="http://sxp4126.uta.cloud/">Blog</a>
        <a class="p-2 text-dark" href="contactus">Contact us</a>

<?php
if(Session::get('user_object')!==null)
{
echo "<a class='p-2 text-dark' href='/signout'>Log Out</a>";
}
else
{
      echo "<a class='p-2 text-dark' href='signin'>Login</a>";  
}
?>

      </nav>

    </div>
</header><?php /**PATH C:\laravel\example-app\resources\views/header.blade.php ENDPATH**/ ?>